// Post Test 2 PBO
// Nama: Zahraturramadhani
// NIM: 2409116014
// Kelas: A'2024 Sistem Informasi

package com.mycompany.posttest2pbo.model;


public class Transaksi {
    private int id;
    private String tanggal;           
    private String keterangan;
    private String jenis;             
    private String kategori;          
    private String metodePembayaran;  
    private double jumlah;

    public Transaksi(int id, String tanggal, String keterangan, String jenis,
                     String kategori, String metodePembayaran, double jumlah) {
        this.id = id;
        this.tanggal = tanggal;
        this.keterangan = keterangan;
        this.jenis = jenis;
        this.kategori = kategori;
        this.metodePembayaran = metodePembayaran;
        this.jumlah = jumlah;
    }

    // Getters & Setters (access modifier: public; field: private)
    public int getId() { return id; }
    public String getTanggal() { return tanggal; }
    public String getKeterangan() { return keterangan; }
    public String getJenis() { return jenis; }
    public String getKategori() { return kategori; }
    public String getMetodePembayaran() { return metodePembayaran; }
    public double getJumlah() { return jumlah; }

    public void setTanggal(String tanggal) { this.tanggal = tanggal; }
    public void setKeterangan(String keterangan) { this.keterangan = keterangan; }
    public void setJenis(String jenis) { this.jenis = jenis; }
    public void setKategori(String kategori) { this.kategori = kategori; }
    public void setMetodePembayaran(String metodePembayaran) { this.metodePembayaran = metodePembayaran; }
    public void setJumlah(double jumlah) { this.jumlah = jumlah; }
    
    
}
